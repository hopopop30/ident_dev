NAS Uploader est un syst�me d'upload multifichiers en Flash tr�s simple � installer et param�trer.

NAS Uploader NE peut PAS �tre vendu.
Utilisation gratuite, Open source.

Je vous demande simplement de bien vouloir mettre un lien vers le site officiel de NAS Uploader www.nasuploader.com sur votre site ou de laisser celui pr�sent dans l'animation flash.

Si vous �tes vraiment altruiste vous pouvez m�me faire un don depuis le site officiel.

N'h�sitez pas � m'envoyer un petit mail avec vos remarques et commentaires et aussi l'adresse du ou des sites sur lesquels vous utilisez NAS Uploader :) �a fait toujours plaisir.

Version 1.5

www.nasuploader.com