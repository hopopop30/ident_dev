<?php
session_start();
$_SESSION['key'] = rand (12345,56789);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>NAS Uploader - Upload multiple</title>
<script language="JavaScript" type="text/javascript" src="Scripts/jsscript.js"></script>
<script language="JavaScript" type="text/javascript" src="Scripts/swfobject.js"></script>
<style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<h1>Upload multiple lanc&eacute; via javascript </h1>
<strong>Comment &ccedil;a marche  ?</strong><br />
- L'animation est charg&eacute;e avec des param&egrave;tres flashVars qui seront envoy&eacute;s en GET &agrave; la suite de l'URL du script serveur<br />
<pre>
so.addParam ('FlashVars','varget=dossierup%3Dtests');</pre>
<br />
<table width="100%" border="0" cellpadding="4" cellspacing="1" bgcolor="#333333">
  <tr>
    <td bgcolor="#333333"><span class="style1">Param&egrave;tres</span></td>
    <td bgcolor="#333333"><span class="style1">signinfcation</span></td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#FFFFFF"><strong>varget=</strong></td>
    <td valign="top" bgcolor="#FFFFFF">Flash recevra une variable nomm&eacute;e varget &agrave; la racine de l'animation (_root.varget)<br />
      Cette variable sera ajout&eacute;e &agrave; l'url du script serveur appel&eacute; &agrave; chaque fichier upload&eacute; dans le code action script <br />
_root.urlUpload = &quot;../upload_filemanager.php?&quot;+varget;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#FFFFFF">dossierup<strong>%3D</strong>tests</td>
    <td valign="top" bgcolor="#FFFFFF"><strong>dossierup</strong> : nom e la variable GET<br />
        <strong>%3D</strong> : symbolise le = encod&eacute; pour une URL</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#FFFFFF">tests</td>
    <td valign="top" bgcolor="#FFFFFF">la valeur de la variable dossierup </td>
  </tr>
  <tr>
    <td colspan="2" valign="top" bgcolor="#FFFFFF">Pour passer plusieurs variables en GET utiliser la syntaxe suivante : </td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#FFFFFF">dossierup<strong>%3D</strong>tests<strong>%26</strong>id<strong>%3D</strong>monID</td>
    <td valign="top" bgcolor="#FFFFFF"><strong>%26 :</strong> symbolise le &amp; encod&eacute; pour une URL ce qui permet d'ajouter des variables </td>
  </tr>
</table>
 <strong><br />
 Au niveau du script serveur</strong><br /> 
   On r&eacute;cup&egrave;re la variable GET dossierup pour cr&eacute;er le chemin d'enregistrement des fichiers<br />
<pre>   $save_path = &quot;uploads/&quot;.$_GET['dossierup'].'/';
  </pre>
   <strong>on essaye d'enregistrer le fichier   </strong>
 <pre>
   	if (move_uploaded_file($_FILES[&quot;Filedata&quot;][&quot;tmp_name&quot;], $save_path.(($_FILES[&quot;Filedata&quot;][&quot;name&quot;])))) {				
         echo utf8_encode('1'); 
	}
	echo '.' ;
	</pre>
On affiche 1 si c'est bon et un point � la fin de l'ex�cution du script car la r�ponse attendue est <strong>1.</strong> si tout s'est bien pass&eacute;. <br />
<form id="form_upload" name="form_upload" method="post" action="">
 <strong>Formulaire </strong><br />
 Ici
 le bouton envoyer est toujours pr&eacute;sent dans l'animation Flash mais le <strong>formulaire HTML</strong> est lui aussi muni d'un bouton qui <strong>a le m&ecirc;me effet.</strong>
 <br />
 Si vous ne souhaitez plus voir apparaitre le bouton dans flash il vous suffit d'&eacute;diter l'animation et de le placer hors de la sc&egrave;ne. D&egrave;s lors seul le bouton du formulaire HTML permettra de commencer l'upload.
 <div style="color:red;"><pre><?php
 if (isset ($_POST) && count($_POST) > 0 ) {
 echo '<strong>Formulaire envoy� !</strong><br /><br />';
 print_r($_POST);
 }
 ?></pre></div><br />
 <label>Champ HTML1<br />
  <input name="champ_html_1" type="text" id="champ_html_1" value="valeur du champ 1" />
  </label>

  <br />
  <br />
  <label>Champ HTML2<br />
  <input name="champ_html_2" type="text" id="champ_html_2" value="valeur du champ 2" />
  </label>
  <br />
  <br />
  <?php
  /*
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="480" height="370" id="FileUploader">
     <param name="movie" value="applications/NasUploader15.swf" />
     <param name="quality" value="high" /> 
     <param name="FlashVars" value="varget=dossierup%3Dtests" />
      <embed src="applications/NasUploader15.swf" id="FileUploader_emb" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="480" height="370" FlashVars="varget=dossierup%3Dtests"></embed>
</object>
*/ ?>

<div id="mon_flash">
		Pour uploader, vous devez telecharger <a href="http://www.adobe.com/go/getflashplayer_fr" onclick="window.open(this.href); return false;"><strong>le player flash</strong></a>
	</div>
	<script type="text/javascript">
		// <![CDATA[
		var so = new SWFObject("./applications/NasUploader15.swf", "nasuploader", "550", "400", "8");
		so.addParam ('FlashVars','varget=dossierup%3Dtests');
		so.write("mon_flash");
		// ]]>
	</script>


<br />
<input type="button" name="btnSubmit" value="lancer l'upload" id="btnSubmit" onclick="goUpload('&variable2=val_variable2'); return false;">    
    </td>

</form>
	
<?php include ('../analitycs.php'); ?>
</body>
</html>
