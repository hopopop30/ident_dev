<?php

/*
ce s cript est appel� par l'animation flash. Prenez note que si vous instanciez une session ici (session_start(); ) elle sera dif�rente de celle de la session instanci�e par l'utilisateur affichant la page HTML contenant NAS Uploader. Vous ne pouvez donc pas acc�der � ses variables de session personnelles 

L'exmple Upload simple lanc� via javascript  vous donne un moyen de contourner ce probl�me. Tout est expliqu�.
*/

	//print_r($_FILES);
		//print_r($_GET);
		
		
		//echo 'var2='.$_GET['variable2'];  //cette variable est envoy�e via javascript en argument de la fonction goUpload
		
	if (isset($_FILES["Filedata"])) {
	 if($_FILES["Filedata"]['error'] == 0){ 
	 
	
	 
	   	$tabfile = explode('.',  $_FILES['Filedata']['name']);
			$nomfile = $tabfile[0];
			$extfi = $tabfile[1];
			
			// si par exemple on a pass� � l'url d'upload un param�tre en GET
			$save_path = "uploads/".$_GET['dossierup'].'/';		
				
				
	if (file_exists($save_path . $_FILES['Filedata']['name'])) {
     echo utf8_encode('Un fichier porte d�j� ce nom dans ce dossier');
  } else {
			
		if (move_uploaded_file($_FILES["Filedata"]["tmp_name"], $save_path.(($_FILES["Filedata"]["name"])))) {
		
				
         echo utf8_encode('1');
	     	
			//on supprime le fichier upload�
	    //unlink ($save_path.(($_FILES["Filedata"]["name"])));
	     	
	     	
	     	} else {
	     	 echo utf8_encode('Erreur d\'�criture');
	     	}
	     	
	     	
	     	
	     	}
	     	
	     	
	     	
	     	
		} else {
		  switch ($_FILES["Filedata"]['error']) {
  		  case 1:
  		  echo 'Fichier trop volumineux';
  		  break;
  		  case 2:
  		  echo 'Fichier trop volumineux';
  		  break;
  		  case 3:
  		  echo 'Fichier incomplet';
  		  break;
  		  case 4:
  		  echo 'Pas de fichier';
  		  break;
  		  case 5:
  		  echo 'Erreur inconnue';
  		  break;
  		  case 6:
  		  echo 'Erreur serveur'; //pas de dossier tmp
  		  break;
  		  case 7:
  		  echo utf8_encode('Erreur d\'�criture');
  		  break;
  		  case 8:
  		  echo 'Extension incorrecte';
  		  break;
  		  default:
  		  echo 'Erreur inconnue';
  		  break;
		  }
		}
	} else {
	  echo utf8_encode("Pas de fichiers envoy�s");
	}
	

		echo utf8_encode('.');
?>
